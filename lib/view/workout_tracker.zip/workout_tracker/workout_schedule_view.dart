import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

import 'add_schedule_view.dart';

class workout_schedule_view extends StatefulWidget {
  final String userId;

  const workout_schedule_view({Key? key, required this.userId}) : super(key: key);

  @override
  _workout_schedule_viewState createState() => _workout_schedule_viewState();
}

class _workout_schedule_viewState extends State<workout_schedule_view> {
  late DatabaseReference _userWorkoutsRef;
  bool _isLoading = true;
  List<Map<dynamic, dynamic>> _workoutsList = [];

  @override
  void initState() {
    super.initState();
    _initFirebase();
  }

  Future<void> _initFirebase() async {
    await Firebase.initializeApp();
    _userWorkoutsRef = FirebaseDatabase.instance.reference().child('users').child(widget.userId).child('scheduled_workouts');
    _userWorkoutsRef.onValue.listen((event) {
      if (event.snapshot.value != null) {
        _workoutsList.clear();
        (event.snapshot.value as Map<dynamic, dynamic>).forEach((key, value) {
          _workoutsList.add({'key': key, 'notificationId': value['notificationId'], ...value});
        });
        setState(() {
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
      }
    });
  }

  // Future<void> _deleteWorkout(String key, int? notificationId) async {
  //   // Delete the workout from Firebase database
  //   await _userWorkoutsRef.child(key).remove();
  //
  //   // Cancel the scheduled notification using the notification ID if it's not null
  //   if (notificationId != null) {
  //     await AwesomeNotifications().cancel(notificationId);
  //   }
  //
  //   // Update the local list of workouts
  //   setState(() {
  //     _workoutsList.removeWhere((workout) => workout['key'] == key);
  //   });
  // }


  Future<void> _deleteWorkout(String key, int? notificationId) async {
    // Delete the workout from Firebase database
    await _userWorkoutsRef.child(key).remove();

    // Cancel the scheduled notification using the notification ID if it's not null
    if (notificationId != null) {
      await AwesomeNotifications().cancel(notificationId);
    }

    // Update the local list of workouts
    setState(() {
      _workoutsList.removeWhere((workout) => workout['key'] == key);
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Scheduled Workouts'),
      ),
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(),
      )
          : _workoutsList.isNotEmpty
          ? ListView.builder(
        itemCount: _workoutsList.length,
        itemBuilder: (context, index) {
          final workout = _workoutsList[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 2)],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(left: 15,top: 10),
                  child: Text(
                    workout['workout'] ?? '',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(height: 5),
                Container(
                  margin: EdgeInsets.only(left: 15,top: 10),
                  child: Text(
                    '${workout['date'] ?? ''} ${workout['time'] ?? ''}',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 15,
                    ),
                  ),
                ),
                SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => _deleteWorkout(workout['key'], workout['notificationId']),
                      child: Text(
                        'Delete',
                        style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),


                  ],
                ),
              ],
            ),
          );
        },
      )
          : Center(
        child: Text('No scheduled workouts found.'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => WorkoutScheduler()),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

    class ScheduleWorkoutPage extends StatelessWidget {
  final String userId;

  const ScheduleWorkoutPage({Key? key, required this.userId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Schedule Workout'),
      ),
      body: Center(
        child: Text('This is where you schedule a workout.'),
      ),
    );
  }
}
