import  '../../common/color_extension.dart';
import 'package:fitness_app/common_widget/round_button.dart';
import 'package:fitness_app/view/workout_tracker/exercises_step_details.dart';
import 'package:flutter/material.dart';
import '../../common_widget/exercises_set_section.dart';
import '../dashboard/home/chatpage.dart';
import 'ABS_beginner/Jumping_Jacks_beginner.dart';

class ABS_Beginner extends StatefulWidget {
  final Map dObj;
  const ABS_Beginner({super.key, required this.dObj});

  @override
  State<ABS_Beginner> createState() => _ABS_BeginnerState();
}

class _ABS_BeginnerState extends State<ABS_Beginner> {

  List exercisesArr = [
    {
      "set": [
        {
          "image": "assets/images/jumping_jacks.png",
          "title": "Jumping Jack",
          "value": "00:20"
        },
        {
          "image": "assets/images/incline_push_ups.png",
          "title": "Abdominal Crunches",
          "value": "x16"
        },

        {
          "image": "assets/images/knee_push_up.png",
          "title": "Russian Twist",
          "value": "x20"
        },
        {
          "image": "assets/images/push_ups.png",
          "title": "Mountain Climber",
          "value": "x16"
        },
        {
          "image": "assets/images/wide_arm_push_ups.png",
          "title": "Wide Arm Push-Ups",
          "value": "x4"
        },
        {
          "image": "assets/images/incline_push_ups.png",
          "title": "Incline Push-Ups",
          "value": "x6"
        },
        {
          "image": "assets/images/knee_push_up.png",
          "title": "Knee Push-Ups",
          "value": "x4"
        },
        {
          "image": "assets/images/push_ups.png",
          "title": "Push-Ups",
          "value": "4x"
        },
        {
          "image": "assets/images/wide_arm_push_ups.png",
          "title": "Wide Arm Push-Ups",
          "value": "x4"
        },
        {
          "image": "assets/images/cobra_stretch.png",
          "title": "Cobra Stretch",
          "value": "00:20"
        },
        {
          "image": "assets/images/chest_Stretch.png",
          "title": "Chest Stretch",
          "value": "00:20"
        },
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    var mediaWidth = MediaQuery.of(context).size.width;

    return Container(
      decoration:
          BoxDecoration(gradient: LinearGradient(colors: Tcolor.primaryG)),
      child: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              backgroundColor: Colors.transparent,
              centerTitle: true,
              elevation: 0,
              leading: Container(
                margin: const EdgeInsets.all(10),
                child: Material(
                  borderRadius: BorderRadius.circular(10),
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  child: InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.all(8),
                      height: mediaWidth * 0.1, // Adjusted height
                      width: mediaWidth * 0.1, // Adjusted width
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Tcolor.lightgray,
                        borderRadius: BorderRadius.circular(mediaWidth * 0.025), // Adjusted borderRadius
                      ),
                      child: Image.asset(
                        "assets/images/black_btn.png",
                        width: mediaWidth * 0.038, // Adjusted width
                        height: mediaWidth * 0.038, // Adjusted height
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                ),
              ) ,
              actions: [
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ChatPage(),
                      ),
                    );
                  },
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(8,12,8,8),
                    height: mediaWidth * 0.092,
                    width: mediaWidth * 0.092,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: Tcolor.lightgray,
                        borderRadius: BorderRadius.circular(10)),
                    child: Image.asset(
                      "assets/images/chat.png",
                      width: 30,
                      height: 30,
                      fit: BoxFit.contain,
                    ),
                  ),
                )

              ],
            ),
            SliverAppBar(
              backgroundColor: Colors.transparent,
              centerTitle: true,
              elevation: 0,
              leadingWidth: 0,
              leading: Container(),
              expandedHeight: media.width * 0.5,
              flexibleSpace: Align(
                alignment: Alignment.center,
                child: Image.asset(
                  "assets/images/detail_top.png",
                  width: media.width * 0.75,
                  height: media.width * 0.8,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ];
        },
        body: Container(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          decoration: BoxDecoration(
              color: Tcolor.white,
              borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(25), topRight: Radius.circular(25))),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Stack(
              children: [
                SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        width: 50,
                        height: 4,
                        decoration: BoxDecoration(
                            color: Tcolor.gray.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(3)),
                      ),
                      SizedBox(
                        height: media.width * 0.05,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.dObj["title"].toString(),
                                  style: TextStyle(
                                      color: Tcolor.black,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700),
                                ),
                                Text(
                                  "${widget.dObj["exercises"].toString()} | ${widget.dObj["time"].toString()} | 320 Calories Burn",
                                  style: TextStyle(
                                      color: Tcolor.gray, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: media.width * 0.05,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Exercises",
                            style: TextStyle(
                                color: Tcolor.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w700),
                          ),
                          // TextButton(
                          //   onPressed: () {},
                          //   child: Text(
                          //     "${youArr.length} Sets",
                          //     style:
                          //         TextStyle(color: Tcolor.gray, fontSize: 12),
                          //   ),
                          // )
                        ],
                      ),
                      ListView.builder(
                          padding: EdgeInsets.zero,
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: exercisesArr.length,
                          itemBuilder: (context, index) {
                            var sObj = exercisesArr[index] as Map? ?? {};
                            return ExercisesSetSection(
                              sObj: sObj,
                              onPressed: (obj) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ExercisesStepDetails(
                                      eObj: obj,
                                    ),
                                  ),
                                );
                              },
                            );
                          }),
                      SizedBox(
                        height: media.width * 0.1,
                      ),
                    ],
                  ),
                ),
                Center(
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 20.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          RoundButton(
                            text: "Start Workout",
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>  jumping_jacks_beginner(),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
